//app.js
App({
  onLaunch: function () {
    let that = this
    console.log("App onLaunch")
    if (!wx.cloud) {
      console.error('请使用 2.2.3 或以上的基础库以使用云能力')
    } else {
      wx.cloud.init({
        // 此处请填入环境 ID, 环境 ID 可打开云控制台查看
        env: 'release-ce15ef',
        traceUser: true,
      })
    }
    wx.cloud.callFunction({
      name: 'login',
      success(res) {
        that.globalData.openId = res.result.openid
        console.log("openId:", that.globalData.openId)
        const db = wx.cloud.database()
        db.collection("Seed").add({
          data: {
            _id: that.globalData.openId,
            globalSeed: 0
          }
        })
        db.collection("Selection").add({
          data:{
            _id:that.globalData.openId,
            select:1
          }
        })
        db.collection("Courses").add({
          data:{
            _id:that.globalData.openId,
            course:null
          }
        })
      },
      fail(res) {
        console.log(res)
      }
    })
  },
  globalData: {
    openId: null,
    seed: null,
    filePaths: [],//对象集合
    photoList: [],//路径序列
    courseNameInfo: [],
    courseTimeInfo: [],
    courseName: null,
    courseTime: null
  }
})
