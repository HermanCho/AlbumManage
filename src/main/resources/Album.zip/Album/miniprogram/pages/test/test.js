// miniprogram/pages/preview/preview.js
const app = getApp()
const db = wx.cloud.database()
var textareaContent
var input
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isDiseditable: false,
    filePaths: [],
    toWhichPhoto: "",
    details: "nice",
    totalChars: 1000,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("preview onLoad")
    let that = this
    let curIndex = options.index
    let Paths = app.globalData.filePaths
    that.setData({
      filePaths: app.globalData.filePaths
    })
    console.log("fileP", that.data.filePaths)
    Paths.forEach((item, index) => {
      let idx = "filePaths[" + index + "].index"
      let details = "filePaths[" + index + "].details"
      let curChars = "filePaths[" + index + "].curChars"
      that.setData({
        [idx]: "index_" + index,
        [details]: "",
        [curChars]: 0
      })
      //从数据库导入文本
      db.collection("Album").doc(item.id).get({
        success(res) {
          that.setData({
            [details]: res.data._details,
            [curChars]: res.data._curChars
          })
        }
      })
    })
    that.setData({
      toWhichPhoto: "index_" + curIndex
    })
    console.log(that.data.toWhichPhoto)
    console.log("filePaths", that.data.filePaths)

  },
  saveBtn(e) {
    console.log("click save")
    let that = this
    let _id = e.detail.target.dataset.id
    let _details = e.detail.value.details
    let _curChars = e.detail.target.dataset.chars
    console.log(e)
    console.log("_id", _id)
    console.log("_details", _details)
    //将文本导入数据库
    db.collection("Album").doc(_id).update({
      data: {
        _details: _details,
        _curChars: _curChars,
      },
      success(res) {
        wx.showToast({
          title: '保存成功!',
          icon: 'success',
          duration: 1000
        })
      }
    })
  },
  bindTextAreaChange: function (e) {
    let that = this
    let _id = e.target.dataset.id
    let _curChars = parseInt(e.detail.value.length);
    let temp = that.data.filePaths
    temp.forEach((item, index) => {
      if (item.id === _id) {
        let curChars = "filePaths[" + index + "].curChars"
        that.setData({
          [curChars]: _curChars
        })
      }
    })
  },
  getWords(e) {
    console.log("click get words")
    console.log(e)
    let that = this
    wx.showLoading({
      title: '提取文字···',
    })
    let _id = e.currentTarget.dataset.id
    //从数据库找fileid
    db.collection("Album").doc(_id).get({
      success(res) {
        let _fileId = []
        _fileId = _fileId.concat(res.data._fileID)
        //用fileid换取图片的临时路径
        wx.cloud.getTempFileURL({
          fileList: _fileId,
          success: res => {
            // get temp file URL
            console.log(res.fileList[0].tempFileURL)
            let url = res.fileList[0].tempFileURL
            let afterReplace = url.replace(/\//g, '&');
            console.log(afterReplace)
            wx.request({
              url: 'https://www.secretzhong.cn:8080/orc2/' + afterReplace,
              success(res) {
                wx.hideLoading()
                wx.showToast({
                  title: '提取成功！',
                  icon: 'success',
                  duration: 2000
                })
                let _words = res.data
                console.log("_words", _words)
                let temp = that.data.filePaths
                temp.forEach((item, index) => {
                  if (item.id === _id) {
                    let _details = "filePaths[" + index + "].details"
                    let _curChars = "filePaths[" + index + "].curChars"
                    that.setData({
                      [_details]: _words,
                      [_curChars]: _words.length
                    })
                  }
                })
              },
              fail: console.error
            })
          },
          file: console.error
        })
      },
      fail: console.error
    })
  },
  //加入收藏
  setFavor(e) {
    console.log("click set favor")
    console.log(e)
    let _id = e.currentTarget.dataset.id
    db.collection("Favor").where({
      _id: _id,
    }).get({
      success(res) {
        if (res.data.length === 1) {
          wx.showToast({
            title: '已收藏！',
            duration: 1000,
            icon: "success"
          })
          console.log("已经收藏过了!")
          return
        }
        else {
          //向Favor数据库中添加字段
          db.collection("Album").doc(_id).get({
            success(res) {
              console.log(res)
              let _data = res.data
              db.collection("Favor").add({
                data: {
                  _albumName: _data._albumName,
                  _date: _data._date,
                  _fileID: _data._fileID,
                  _id: _data._id
                },
                success(res) {
                  wx.showToast({
                    title: '收藏成功！',
                    duration: 1000,
                    icon: "success"
                  })
                  console.log(res)
                },
                fail: console.error
              })
            },
            fail: console.error
          })
        }
      },
      fail: console.error
    })
  },
  photoPreview(e) {
    console.log("click photo review")
    console.log(e)
    let url = e.currentTarget.dataset.src
    let urls = []
    urls = urls.concat(url)
    wx.previewImage({
      urls: urls
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
})