// miniprogram/pages/course/course.js
const app = getApp()
const db = wx.cloud.database()
var tourist = 0
Page({

  /**
   * 页面的初始数据
   */
  data: {
    array: ['经典模式', '简洁模式'],
    index: 0,
    courseList: [],
    local: "http://localhost",
    net: "https://www.secretzhong.cn",
    isManagement: false,
    managementContent: "管理",

    deleteOrCancle: "删除",

    courseConcise: [],
    extra: [],
    isHide: true,
    cancelShow: false,

    DefaultStyle: true,
    ConciseStyle: false

  },
  clickManagement() {
    console.log("click management")
    let that = this
    let im = !that.data.isManagement
    if (that.data.managementContent == "管理") {
      that.setData({
        managementContent: "隐藏"
      })
    } else {
      that.setData({
        managementContent: "管理"
      })
    }
    that.setData({
      isManagement: im
    })
  },

  updateData: function () {
    var that = this;
    var ybAuth = wx.getStorageSync('Authorized');
    if (ybAuth) {
      console.log("yb授权");
      that.freshData();
      wx.navigateTo({
        url: '../login/login',
      })
    } else {
      console.log("跳转易班");
      wx.navigateTo({
        url: '../getAut/getAut',
      })
    } 
  },

  freshData: function () {
    var that = this;
    wx.request({
      url: that.data.net + ':8080/reload',
      success: function (res) {
        var result = res.data.success;
        console.log("course页登录成功后更新数据");
      }
    });
  },

  getCourseNameAndTime: function () {
    var that = this;
    var courseNameTmp = [];
    var courseTimeTmp = [];
    var courseList = wx.getStorageSync('courseList');
    // var courseList = this.data.courseList;
    if (courseList) {
      console.log(courseList);
    }
    for (var i = 0; i < courseList.length; i++) {
      var each = courseList[i];
      for (var j = 1; j < each.length; j++) {
        var courseinfo = each[j];
        var pos = courseinfo.split("\n");
        if (pos != null && pos != "") {
          var courseName = pos[0];
          var courseTime = pos[1];
          var exist = false;

          //获得单一名字及对应时间，防止重复
          {
            for (var m = 0; m < courseNameTmp.length; m++) {
              //若名字已存在，则在对应的时间数组加上时间段
              if (courseName == courseNameTmp[m]) {
                courseTimeTmp[m] += ' ' + courseTime;
                exist = true;
                break;
              }
            }
            if (exist == false) {
              courseNameTmp.push(courseName);
              courseTimeTmp.push(courseTime);
            }
          }
          //获得单一名字及对应时间，防止重复
        }
      }
    }
    //把处理好的数组赋值给全局变量
    //tips：其实可以用类似java的Map 一一对应方法，查找起来效率更高
    getApp().globalData.courseNameInfo = courseNameTmp;
    getApp().globalData.courseTimeInfo = courseTimeTmp;
    console.log("courseName", courseNameTmp)
    db.collection("Courses").doc(app.globalData.openId).update({
      data: {
        course: courseNameTmp
      }
    })
  },

  bindModelChange: function (e) {
    let that = this
    if (that.data.DefaultStyle == true) {
      that.setData({
        DefaultStyle: false,
        ConciseStyle: true
      })
      db.collection("Selection").doc(app.globalData.openId).update({
        data: {
          select: 1
        }
      })
      wx.setNavigationBarTitle({
        title: '课表（简洁模式）',
      })
    } else {
      that.setData({
        DefaultStyle: true,
        ConciseStyle: false
      })
      db.collection("Selection").doc(app.globalData.openId).update({
        data: {
          select: 0
        }
      })
      wx.setNavigationBarTitle({
        title: '课表（经典模式）',
      })
    }
    that.setData({
      isManagement: false,
      managementContent: "管理"
    })
  },

  toPhotoD: function (e) {
    var tmp = e.target.dataset.courseinfo;
    if (tmp != undefined && tmp != "") {
      var pos = tmp.split("\n");
      var courseName = pos[0];
      var courseTime = null;
      wx.showModal({
        title: courseName,
        content: "是否查看 \"" + courseName + "\"的相关照片",
        success: function (res) {
          if (res.confirm) { //这里是点击了确定以后
            var info = getApp().globalData.courseNameInfo;
            for (var i = 0; i < info.length; i++) {
              if (courseName == info[i]) {
                courseTime = getApp().globalData.courseTimeInfo[i];
                break;
              }
            }
            getApp().globalData.courseName = courseName;
            getApp().globalData.courseTime = courseTime; // 设置全局变量值
            wx.navigateTo({
              url: '../photos/photos?name=' + courseName
            })
          }
        }
      })
    }
  },
  toPhoto: function (e) {
    console.log("click")
    console.log(e);
    var courseName = e.target.dataset.coursename;
    var courseTime = null;
    if (courseName != undefined && courseName != "") {
      wx.showModal({
        title: courseName,
        content: "是否查看 \"" + courseName + "\"的相关照片",
        success: function (res) {
          if (res.confirm) { //这里是点击了确定以后
            var info = getApp().globalData.courseNameInfo;
            for (var i = 0; i < info.length; i++) {
              if (courseName == info[i]) {
                courseTime = getApp().globalData.courseTimeInfo[i];
                break;
              }
            }
            getApp().globalData.courseName = courseName;
            getApp().globalData.courseTime = courseTime; // 设置全局变量值
            wx.navigateTo({
              url: '../photos/photos?name=' + courseName
            })
          }
        }
      })
    }
  },

  
  onShow: function () {
    this.setData({
      extra: wx.getStorageSync('extra')
    })
    if (tourist == "1") {
      console.log("游客onshow");
      return;
    }
    var that = this;
    var cl = wx.getStorageSync('courseList');
    this.setData({
      extra: wx.getStorageSync('extra')
    })
    if (!cl) {
      console.log("cl为空，访问以加载数据")
      wx.request({
        url: that.data.net + ":8080/login/getcourse",
        data: {},
        method: 'POST',
        header: {
          'content-type': 'application/json'
        },
        success: function (res) {
          var result = res.data.success;
          if (result != true) {
            wx.showModal({
              title: '获取课表失败',
              content: '是否重新获取课表？',
              success(res) {
                if (res.confirm) {
                  that.onShow();
                } else if (res.cancel) {
                  wx.navigateBack({
                    delta: 1
                  })
                  // wx.navigateTo({
                  //   url: '../login/login',
                  // })
                }
              }
            });
          } else {
            var tmp = res.data.course;
            wx.setStorageSync('courseList', tmp);
            that.setData({
              courseList: tmp
            });
          }
          that.freshData();
          that.getCourseNameAndTime();
        }

      })
    } else {
      that.setData({
        courseList: cl
      });
      that.getCourseNameAndTime();
    }
  },

  onLoad: function (options) {
    let that = this;
    this.setData({
      extra: wx.getStorageSync('extra')
    })
    tourist = options.tourist
    console.log("options", options)
    if (options.style == "0") {
      that.setData({
        DefaultStyle: true,
        ConciseStyle: false
      })
      wx.setNavigationBarTitle({
        title: '课表（经典模式）',
      })
    } else {
      that.setData({
        DefaultStyle: false,
        ConciseStyle: true
      })
      wx.setNavigationBarTitle({
        title: '课表（简洁模式）',
      })
    }

    if (tourist == "1") {
      console.log("游客onload");
      return;
    }
    this.setData({
      courseConcise: getApp().globalData.courseNameInfo,
    })
    db.collection("Courses").where({
      _id: app.globalData.openId
    }).get({
      success(res) {
        console.log(res.data[0].course)
        that.setData({
          courseConcise: res.data[0].course
        })
      },
      fail: console.error
    })
  },


  //去我的收藏
  toMyFavor() {
    console.log("click to my favor")
    wx.navigateTo({
      url: '../myfavor/myfavor?name=' + "我的收藏",
    })
  },
  onHide: function () {
    let that = this
    that.setData({
      isManagement: false,
      managementContent: "管理"
    })
  },


  addExtra: function () {
    var that = this;
    that.setData({
      isHide: false,
      isManagement: false,
      managementContent: "管理"
    })

  },
  cancleAndBack2Course() {
    let that = this
    that.setData({
      isHide: true,
    })
  },
  showDelete: function () {
    var that = this;
    if (that.data.cancelShow == true) {
      that.setData({
        cancelShow: false,
        deleteOrCancle: "删除",
      })
    } else {
      that.setData({
        cancelShow: true,
        deleteOrCancle: "取消",
      })
    }
  },

  deleteExtra: function (e) {
    var that = this;
    var courseName = e.target.dataset.coursename;
    console.log("deleteExtra" + courseName);
    wx.showModal({
      title: courseName,
      content: "是否删除 \"" + courseName + "\"及其相关照片",
      success: function (res) {
        if (res.confirm) { //这里是点击了确定以后
          var extra = wx.getStorageSync('extra');
          var pos = extra.indexOf(courseName);
          extra.splice(pos, 1);
          wx.setStorageSync('extra', extra);
          that.setData({
            extra: wx.getStorageSync('extra')
          })
        }
        that.setData({
          cancelShow: false,
          deleteOrCancle: "删除"
        });
      }
    });
  },

  extraData: function (e) {
    var that = this;
    var name = e.detail.value.album;
    if (!name) {
      wx.showToast({
        title: '相册名不能为空',
        icon: 'none',
        duration: 3000
      })
    } else {
      var extra = wx.getStorageSync('extra') || []; {
        var exist = false;
        for (var m = 0; m < extra.length; m++) {
          //若名字已存在，则在对应的时间数组加上时间段
          if (name == extra[m]) {
            exist = true;
            break;
          }
        }
        var toastText = '添加成功';
        if (exist == false) {
          extra.push(name);
          wx.setStorageSync('extra', extra)
        } else {
          toastText = '该相册已存在';
        }
        wx.showToast({
          title: toastText,
          icon: '',
          duration: 3000
        });
      }
      that.setData({
        isHide: true
      });
      if (exist == false) {
        wx.navigateTo({
          url: '../photos/photos?name=' + name
        })
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */

  onHide: function () {
    let that = this
    that.setData({
      isManagement: false,
      managementContent: "管理"
    })
  },
})