// miniprogram/pages/judge/judge.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //授权顺序由上而下，步骤进行越前
    var all = wx.getStorageSync('loginStatus');
    var wcAuth = wx.getStorageSync('wechatAuthorized');
    var ybAuth = wx.getStorageSync('Authorized');
    if (all) {
      console.log("全部授权，跳转课表");
      db.collection("Selection").where({
        _openid: app.globalData._openid
      }).get({
        success(res) {
          let style = 0
          console.log(res)
          if (res.data[0].select === 1) {
            style = 1
          }
          wx.redirectTo({
            url: '../course/course?style=' + style,
          })
        },
        fail: console.error
      })
    } else if (ybAuth) {
      console.log("易班，微信已有，跳转登录");
      wx.redirectTo({
        url: '../login/login',
      })
    } else if (wcAuth) {
      console.log("微信已授权，简洁模式");
      wx.redirectTo({
        url: '../course/course?style=' + 1 + "&tourist=1",
      })
    } else {
      console.log("均无，跳转微信授权初始页面");
      wx.redirectTo({
        url: '../first/first',
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})