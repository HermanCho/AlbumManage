// pages/t/t.js
Page({

  /**
   * 页面的初始数据
   */

  
  
  
  // 13719133607  chm159753
  data: {
    local: "http://localhost",
    net: "https://www.secretzhong.cn",
    id1: "bc20d1eef7f79107",
    id2: "68b65b2ab75d8574",
  },

  formSubmit: function (e) {
    var that = this;
    var user = e.detail.value.user;
    wx.showLoading({
      title: '正在登录',
    });
    var password = e.detail.value.password;
    var formData = e.detail.value; //得到的是json数据
    console.log('易班submit', formData)
    wx.request({
      url: that.data.net + ":8080/yblogin?user="
        + user + "&password=" + password,
      // data: JSON.stringify(formData),
      method: 'GET',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        var result = res.data.success;
        wx.hideLoading();
        if (!result) {
          wx.showModal({
            title: '易班验证失败',
            showCancel: false,
          });
        } else {
          var toastText = "登录成功";
          wx.showToast({
            title: toastText,
            icon: '',
            duration: 5000
          });
          //保存用户信息到本地缓存，下载load直接加载
          wx.setStorageSync('Authorized', 'true');
          wx.redirectTo({
            url: '../login/login',
          })
          wx.hideToast();
        }
      }
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("触发获取权限的load事件");
    var that = this;
    var finish = wx.getStorageSync('Authorized');
    if (finish) {
      wx.redirectTo({
        url: '../login/login',
      })
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log("触发onshow事件");
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})