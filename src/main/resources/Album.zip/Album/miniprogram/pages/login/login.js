// miniprogram/pages/login/login.js
const app = getApp()
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */

  //  201727010101    chm981014
  data: {
    userName: '',
    password: '',
    checkCode: '',
    imageUrl: '',
    local: "http://localhost",
    net: "https://www.secretzhong.cn"
  },
  /**
   * 提交表单
   */
  formSubmit: function (e) {
    var t1 = e.detail.value.userName;
    var t2 = e.detail.value.password;
    var that = this;
    that.setData({
      userName: t1, //保存用户信息
      password: t2
    });
    var formData = e.detail.value; //得到的是json数据
    console.log('submit事件', formData)
    wx.request({
      url: that.data.net + ":8080/login",
      data: JSON.stringify(formData),
      method: 'POST',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        var result = res.data.success;
        var content = res.data.failMessage;
        if (!result) {
          wx.showModal({
            title: '登录失败',
            content: res.data.failMessage,
            showCancel: false,
            success: function (res) {
              //重新加载验证码
              that.refreshCheckCode();
              var b = content.indexOf('请再次尝试');
              if (b != -1) {
                that.updateData();
              }
            }
          });
        } else {
          var toastText = "登录成功";
          wx.showToast({
            title: toastText,
            icon: '',
            duration: 5000
          });
          //保存用户信息到本地缓存，下载load直接加载
          wx.setStorageSync('userName', t1);
          wx.setStorageSync('password', t2);
          wx.setStorageSync('loginStatus', 'true');
          //登陆成功，记录登录状态
          wx.hideToast();
          console.log("全部授权，跳转课表");
          db.collection("Selection").where({
            _openid: app.globalData._openid
          }).get({
            success(res) {
              console.log(res)
              let style = 0
              if(res.data[0] === 1){
                style = 1
              }
              wx.redirectTo({
                url: '../course/course?style='+style,
              })
            },
            fail: console.error
          })
        }
      }
    })
  },

  updateData: function () {
    var that = this;
    wx.request({
      url: that.data.net + ':8080/reload',
      success: function (res) {
        var result = res.data.success;
        console.log("login页更新数据");
      }
    });
  },

  /**
   * 登录失败后执行，只保存用户名，密码验证码清空
   */

  /**
   * 刷新验证码
   */
  refreshCheckCode: function () {
    var that = this;
    that.setData({
      checkCode: ''
    })
    wx.request({
      url: that.data.net + ':8080/refresh',
      success: function (res) {
        var result = res.data.success;
        if (result) {
          that.setData({
            imageUrl: that.data.net + ':8080/getpic/pic.png' + '?' + Date.parse(new Date())
          });
        } else {
          var toastText = "验证码加载失败";
          wx.showToast({
            title: toastText,
            icon: '',
            duration: 2000
          });
        }
      },
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("会触发load事件")
    // var that = this;
    // that.updateData();
    // that.refreshCheckCode();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */

  //缓存相关均为同步(syc)，保证数据安全
  onShow: function () {
    var that = this;
    var userName = wx.getStorageSync("userName");
    var password = wx.getStorageSync("password");
    if (userName && password) {
      console.log("从缓存中获取userName password");
      that.setData({
        userName: userName,
        password: password
      });
    }
    that.updateData();
    that.refreshCheckCode();
  },

  tourists(){
    wx.redirectTo({
      url: '../course/course?style='+1+"&tourist=1",
    })
  }
})