const app = getApp()
const db = wx.cloud.database()  //获取数据库引用
var fileIDList_DownLoad = []    //用在页面onload时保存从数据库导入的fileID
var tempFilePathList = []       //图片的临时路径序列
var tempFileDateList = []       //图片日期序列
var deleteList = []             //要被删除的图片序列
Page({
  //页面的初始数据
  data: {
    albumName:"", //相册名
    filePaths:[], //临时路径序列
    fileDateList:[],
    imgOpacity:1,  //图片透明度
    ManageOrCancel: "管理",//管理、取消按键
    isDelete: false,//删除
    isShowDelete: false,//是否显示删除框
    isDelBtnDisable: true,//删除是否可用
  },
  //监听页面加载
  onLoad: function (options) {
    console.log("相册页 onLoad")
    let that = this
    let name = options.name
    that.setData({  //设置相册标题
      albumName:name
    })
    //获取该学科的seed
    db.collection("Seed").where({
      _openid:app.globalData.openId,
    }).get({
      success(res){
        console.log("Global Seed: ", res.data[0].globalSeed)
        app.globalData.seed = res.data[0].globalSeed
      }
    })
    //读取该openID下该学科的图片
    db.collection('Album').where({//筛选条件：1用户openid、2科目类别
      _openid: app.globalData.openId,
      _albumName: that.data.albumName
    }).get({
      success(res) {
        //遍历筛选后的集合，拼接他们的fileID
        let seedList = res.data
        console.log("seedList:",seedList)
        res.data.forEach((item) => {
          console.log("item",item)
          fileIDList_DownLoad = fileIDList_DownLoad.concat(item._fileID)
          tempFileDateList = tempFileDateList.concat(item._date)
        })
        //得到该科目下的日期序列
        let fileDateList = Array.from(new Set(tempFileDateList))
        console.log("date list",fileDateList)
        that.setData({
          fileDateList:fileDateList
        })
        //通过fileID集合换取图片临时路径
        wx.cloud.getTempFileURL({
          fileList: fileIDList_DownLoad,
          success: res => {
            res.fileList.forEach((item) => {
              console.log(item.tempFileURL)
              tempFilePathList = tempFilePathList.concat(item.tempFileURL)
            })
            //设置data中的临时路径对象数组
            tempFilePathList.forEach((item, index) => {
              let id = "filePaths[" + index + "].id"
              let _id = seedList[index]._id
              let path = "filePaths[" + index + "].path"
              let checked = "filePaths[" + index + "].checked"
              let date = "filePaths[" + index + "].date"
              let _date = tempFileDateList[index]
              that.setData({
                [id]: _id,
                [path]: item,
                [checked]: false,
                [date]: _date
              })
              //将图片路径序列保存为全局变量，方便图片preview时的查找
              app.globalData.photoList = app.globalData.photoList.concat(item)
            })
          },
          fail:console.error
        })
      }
    })
  },
  //上传按钮
  upLoad(){
    console.log("cilic upLoad")
    let that = this
    //选择要上传的图片
    wx.chooseImage({
      count: 9,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        wx.showLoading({
          title: '上传中···',
        })
        //批量上传的实现
        res.tempFilePaths.forEach((item,index) => {
          let date = new Date()   //获取日期
          let today = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate()
          var seed = app.globalData.seed++
          var seedID = that.data.albumName+seed     //图片id以 相册名+种子号 命名
          tempFileDateList = tempFileDateList.concat(today)
          wx.cloud.uploadFile({
            //拼接上传路径
            // cloudPath: app.globalData.openId + "/" + that.data.albumName + "/" + today + "/" + seed + ".png",
            cloudPath: app.globalData.openId + "/" + today + "/" + seed + ".png",
            filePath: item,//文件路径
            success(res) {
              console.log("上传成功！")
              console.log("upLoad fileID: ",res.fileID)
              wx.hideLoading()
              wx.showToast({
                title: '上传成功！',
                icon: 'success',
                duration: 1000
              })
              //添加到数据库的Album集合中
              db.collection("Album").add({
                data:{
                  _fileID:res.fileID,
                  _albumName:that.data.albumName,
                  _date:today,
                  _id:seedID
                },
                success(res){
                  console.log(res)
                },
                fail(res){
                  console.log(res)
                }
              })
            }
          })
          //将图片路径序列保存为全局变量，方便图片preview时的查找
          app.globalData.photoList = app.globalData.photoList.concat(item)
          //得到该科目下的日期序列
          let fileDateList = Array.from(new Set(tempFileDateList))
          console.log("date list", fileDateList)
          that.setData({
            fileDateList: fileDateList
          })
          //更新data中的临时图片路径对象数组
          let tempFilePathList = that.data.filePaths
          let newindex = tempFilePathList.length
          let id = "filePaths[" + newindex + "].id"
          let path = "filePaths[" + newindex + "].path"
          let checked = "filePaths[" + newindex + "].checked"
          let _date = "filePaths[" + newindex + "].date"
          let _path = item
          that.setData({
            [id]: seedID,
            [path]: _path,
            [checked]: false,
            [_date]:today
          })
          tempFilePathList = tempFilePathList.concat(item)
        })
        //更新数据库中的种子集合
        db.collection('Seed').doc(app.globalData.openId).set({
          data: {
            globalSeed: app.globalData.seed
          },
          success(res) {
            console.log(res)
          },
          fail(res) {
            console.log(res)
          }
        })
      },
      fail:console.error
    })
  },
  //点击管理
  management() {
    console.log("click Management")
    let that = this
    let change = !that.data.isShowDelete
    console.log(change)
    that.setData({
      isShowDelete: change
    })
    if (that.data.isShowDelete === true){
      that.setData({
        imgOpacity:0.7,
        isDelete:true,
        ManageOrCancel:"取消"
      })
    }
    else{
      that.setData({
        imgOpacity:1,
        isDelete:false,
        ManageOrCancel:"管理"
      })
    }
  },
  //check-box事件
  checkboxChange: function (e) {
    let that = this
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    //获得要被删除的图片的序列
    deleteList = e.detail.value
    console.log("delete List", deleteList)
    if(e.detail.value.length === 0){
      that.setData({
        isDelBtnDisable:true
      })
    }
    else{
      that.setData({
        isDelBtnDisable: false
      })
    }
  },
  //删除图片
  deleteImg(e) {
    wx.showLoading({
      title: '删除中···',
    })
    console.log("click delete")
    let that = this
    var tempFilePaths = that.data.filePaths
    console.log("filePaths: ",tempFilePaths)
    //删除功能模块的显示控制（管理按钮、删除按钮、删除选框）
    that.setData({
      ManageOrCancel: "管理",
      imgOpacity:1,
      isDelete: false,
      isShowDelete: false,
      isDelBtnDisable:true
    })
    //删除图片，然后更新data中的临时图片路径数组
    deleteList.forEach((item,index)=>{
      for(let i = 0 ; i < tempFilePaths.length ; i ++){
        if(item == tempFilePaths[i].id){
          tempFilePaths.splice(i,1)
          tempFileDateList.splice(i,1)
          //将图片路径序列保存为全局变量，方便图片preview时的查找
          app.globalData.photoList.splice(i,1)
        }
      }
    })
    //得到该科目下的日期序列
    let fileDateList = Array.from(new Set(tempFileDateList))
    console.log("date list", fileDateList)
    that.setData({
      fileDateList: fileDateList
    })
    console.log("after delete: ",tempFilePaths)
    that.setData({
      filePaths : tempFilePaths
    })
    //先从数据库删除
    deleteList.forEach((item,index)=>{
      let deleteFileIDList = []
      console.log(item)
      db.collection("Album").where({
        _openid:app.globalData.openId,
        _id:item
      }).get({
        success(res){
          console.log("get delete fileId",res.data[0]._fileID)
          deleteFileIDList = deleteFileIDList.concat(res.data[0]._fileID)
          //然后在存储中删除
          wx.cloud.deleteFile({
            fileList: deleteFileIDList,
            success: res => {
              console.log(res.fileList)
              var _id = item
              db.collection("Album").doc(_id).remove({
                success(res){
                  wx.hideLoading()
                  wx.showToast({
                    title: '删除成功',
                    icon: 'success',
                    duration: 1000
                  })
                  db.collection("Favor").doc(item).remove({
                    success:console.success,
                    fail:console.error
                  })
                },
                fail: console.error
              })
            },
            fail:console.error
          })
        }
      })
    })
  },
  //去照片预览页
  gotoPreview(event){
    console.log("go to preview")
    let that = this
    let curPath = event.currentTarget.dataset.src
    let curIndex
    app.globalData.photoList.forEach((item,index)=>{
      if(item == curPath){
        console.log("find!")
        console.log("index:",index)
        curIndex = index
      }
    })
    console.log("curIndex",curIndex)
    app.globalData.filePaths = that.data.filePaths
    if(that.data.isShowDelete === true){
      return 
    }
    wx.navigateTo({
      url: '../preview/preview?index='+curIndex,
    })
    // wx.navigateTo({
    //   url: '../test/test?index=' + curIndex,
    // })
  },
  //监听页面初次渲染完成
  onReady: function () {
    console.log("相册页 onReady")
  },
  //监听页面显示
  onShow: function () {
    console.log("相册页 onShow")
  },
  //监听页面隐藏
  onHide: function () {
    console.log("相册页 onHide")
  },
  //监听页面卸载
  onUnload: function () {
    console.log("相册页 onUnload")
    let that = this
    fileIDList_DownLoad = []
    tempFilePathList = []
    tempFileDateList = []
    that.setData({
      filePaths:[]
    })
    app.globalData.filePaths = []
    app.globalData.photoList = []
  },
})
